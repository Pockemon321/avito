from django.contrib import admin
from .models import Ad, Review, Category


admin.site.register(Ad)
admin.site.register(Review)
admin.site.register(Category)
